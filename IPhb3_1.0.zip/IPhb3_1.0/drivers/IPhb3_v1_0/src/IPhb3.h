
#ifndef IPHB3_H
#define IPHB3_H


/****************** Include Files ********************/
#include "stdint.h"
#include "stdbool.h"
#include "xil_types.h"
#include "xil_io.h"
#include "xstatus.h"

#define IPHB3_S00_AXI_SLV_REG0_OFFSET 0
#define IPHB3_S00_AXI_SLV_REG1_OFFSET 4
#define IPHB3_S00_AXI_SLV_REG2_OFFSET 8
#define IPHB3_S00_AXI_SLV_REG3_OFFSET 12


/*
// canonical register declaration
#define PMODENC_STS_OFFSET		PMODENC_S00_AXI_SLV_REG0_OFFSET
#define PMODENC_CNTRL_OFFSET 	PMODENC_S00_AXI_SLV_REG1_OFFSET
#define PMODENC_COUNT_OFFSET	PMODENC_S00_AXI_SLV_REG2_OFFSET
#define PMODENC_RSVD00_OFFSET	PMODENC_S00_AXI_SLV_REG3_OFFSET
*/
/**************************** Type Definitions *****************************/
/**
 *
 * Write a value to a IPHB3 register. A 32 bit write is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is written.
 *
 * @param   BaseAddress is the base address of the IPHB3device.
 * @param   RegOffset is the register offset from the base to write to.
 * @param   Data is the data written to the register.
 *
 * @return  None.
 *
 * @note
 * C-style signature:
 * 	void IPHB3_mWriteReg(u32 BaseAddress, unsigned RegOffset, u32 Data)
 *
 */
#define IPHB3_mWriteReg(BaseAddress, RegOffset, Data) \
  	Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))

/**
 *
 * Read a value from a IPHB3 register. A 32 bit read is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is read from the register. The most significant data
 * will be read as 0.
 *
 * @param   BaseAddress is the base address of the IPHB3 device.
 * @param   RegOffset is the register offset from the base to write to.
 *
 * @return  Data is the data from the register.
 *
 * @note
 * C-style signature:
 * 	u32 IPHB3_mReadReg(u32 BaseAddress, unsigned RegOffset)
 *
 */
#define IPHB3_mReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))

/************************** Function Prototypes ****************************/
/**
 *
 * Run a self-test on the driver/device. Note this may be a destructive test if
 * resets of the device are performed.
 *
 * If the hardware system is not built correctly, this function may never
 * return to the caller.
 *
 * @param   baseaddr_p is the base address of the IPHB3 instance to be worked on.
 *
 * @return
 *
 *    - XST_SUCCESS   if all self-test code passed
 *    - XST_FAILURE   if any self-test code failed
 *
 * @note    Caching must be turned off for this function to work.
 * @note    Self test may fail if data memory and device are not on the same bus.
 *
 */
XStatus IPHB3_Reg_SelfTest(void * baseaddr_p);
/*
// self test and initialization functions
uint32_t pmodENC_selftest(uint32_t baseaddr);
uint32_t pmodENC_initialize(p_pmodENC instance, uint32_t baseaddr);

//rotary encoder functions
uint32_t pmodENC_init(p_pmodENC p_instance, int32_t incr_decr_cnt, bool no_neg);
uint32_t pmodENC_clear_count(p_pmodENC p_instance);
uint32_t pmodENC_read_count(p_pmodENC p_instance, uint16_t* p_rotary_count);

// button and switch functions
bool pmodENC_is_button_pressed(p_pmodENC p_instance);
bool pmodENC_is_switch_on(p_pmodENC p_instance);

#endif // PMODENC_H
*/
#endif // IPHB3_H
